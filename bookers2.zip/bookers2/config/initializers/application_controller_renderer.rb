# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '7ac25995c238756eadcbaabb5dea747d69b8180b668fb3aa1736456b553cae6e700c92d187dc5078a50304f3ffb1b90bd6f25cf1acd6e0f16ed5ba9d8a8cb93b'